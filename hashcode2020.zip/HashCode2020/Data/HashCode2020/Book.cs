﻿namespace HashCode2020.Data.HashCode2020
{
    public class Book
    {
        public int Score { get; set; }
        public bool IsScanned { get; set; }
        public int ScannedFromLibrary { get; set; }
        public int ScannedAtDay { get; set; }
    }
}