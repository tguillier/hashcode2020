﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using HashCode2020.Data.HashCode2020;

namespace HashCode2020
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string[] files = Directory.GetFiles("Data\\inputs");

            int globalScore = 0;
            
            foreach(string file in files)
            {
                string rawData = File.ReadAllText(file);
                BookDataFormat bdf = new BookDataFormat(rawData);
                var globalData = bdf.CreateFromRawData();
                string calculated = ""; // compute(globalData)
                calculated = @"2
1 3
5 2 3
0 5
0 1 2 3 4";
                int score = new Scorer().getScore(globalData, calculated);
                Console.WriteLine($"Score sur le fichier {file} : {score}");
                globalScore += score;

                try
                {
                    string fileName = $"\\outputs\\{file.Split("\\").LastOrDefault()}";
                    if (File.Exists(fileName))
                    {
                        File.Delete(fileName);
                    }

                    // Create a new file     
                    using (FileStream fs = File.Create(fileName))
                    {
                        // Add some text to file    
                        Byte[] title = new UTF8Encoding(true).GetBytes(calculated);
                        fs.Write(title, 0, title.Length);
                    }
                }
                catch (Exception Ex)
                {
                    Console.WriteLine(Ex.ToString());
                }
            }

            Console.WriteLine($"Score global : {globalScore}");

            Console.ReadLine();
        }
    }
}
